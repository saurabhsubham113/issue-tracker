import React, { useState } from 'react'
import { Form, FormGroup, Input, Button, Label, Card, CardHeader, CardBody, CardFooter } from 'reactstrap'
import { Redirect, useHistory } from "react-router-dom";
import { getUser } from '../../action/user.action'
import { useDispatch, useSelector } from 'react-redux';

const SignIn = () => {
    const dispatch = useDispatch()
    const history = useHistory()
    const currentUser = useSelector(state => state.users.user)
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    const handleSubmit = (e) => {
        e.preventDefault()
        dispatch(getUser(email, password))

        setEmail("")
        setPassword("")
    }

    const handleEmail = e => {
        setEmail(e.target.value)
    }

    const handlePassword = e => {
        setPassword(e.target.value)
    }

    const isSucess = () => {
        if (currentUser) {
            return true
        }else
            return false
    }

    return (
        <>
            {isSucess() ? <Redirect to="/" /> :
                (<Card className="w-50 m-auto">
                    <Form onSubmit={handleSubmit} >
                        <CardHeader className="text-center">SIGN IN</CardHeader>
                        <CardBody>

                            <FormGroup>
                                <Label htmlFor="email">Email</Label>
                                <Input
                                    type="email"
                                    name="email"
                                    id="email"
                                    onChange={handleEmail}
                                    value={email}
                                    placeholder="Enter your email"
                                    required
                                />
                            </FormGroup>
                            <FormGroup>
                                <Label htmlFor="password">Password</Label>
                                <Input
                                    type="password"
                                    name="password"
                                    id="password"
                                    value={password}
                                    onChange={handlePassword}
                                    placeholder="Enter your password"
                                    required
                                />
                            </FormGroup>
                        </CardBody>
                        <CardFooter>
                            <Button className="m-auto" color="success" type="submit" >Sign In</Button>
                            <Button className="float-right" color="warning" onClick={() => history.push("/signup")}  >Sign up</Button>
                        </CardFooter>
                    </Form>
                </Card>)
            }
        </>
    )
}

export default SignIn
