import React, {  useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import {
    Collapse,
    Navbar,
    NavbarBrand,
    NavbarToggler,
    Nav,
    NavItem,
    NavLink,
    NavbarText
} from "reactstrap";
import { logOut } from '../../action/user.action';

const Header = () => {

    const dispatch = useDispatch()
    const [isOpen, setIsOpen] = useState(false)
    const user = useSelector(state => state.users.user)
    const toggle = () => setIsOpen(!isOpen)

    const handleLogout = () => {
        dispatch(logOut())
        
            toast("Logout successful",{
                type:"success"
            })
      
    }
    return (
        <Navbar color="info" light expand="md" className="mb-4">
            <NavbarBrand >
                <Link to="/" className="text-white">Issue Tracker</Link>
            </NavbarBrand>

            <NavbarText className="text-white">
                {user?.email ? `Welcome ${user.firstName} !`: ""}
            </NavbarText>

            <NavbarToggler onClick={toggle} />

            <Collapse isOpen={isOpen} navbar>
                <Nav className="ml-auto" navbar>
                    {
                        user ? (
                            <NavItem>
                                <div 
                                style={{cursor:"pointer"}}
                                onClick={handleLogout} 
                                className="text-white">
                                    Log out
                                </div>
                            </NavItem>

                        ) : (
                                <>
                                    <NavItem>
                                        <NavLink tag={Link} to="/signin" className="text-white">
                                            Sign In
                                        </NavLink>
                                    </NavItem>
                                    <NavItem>
                                        <NavLink tag={Link} to="/signup" className="text-white">
                                            Sign Up
                                        </NavLink>
                                    </NavItem>
                                </>

                            )
                    }


                </Nav>
            </Collapse>
        </Navbar>
    )
}

export default Header
