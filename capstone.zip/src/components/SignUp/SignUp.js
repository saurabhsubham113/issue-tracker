import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { Form, FormGroup, Input, Button, Label, Row, Card, CardHeader, CardBody, CardFooter, } from 'reactstrap'
import { addUser } from '../../action/user.action'
import { nanoid } from "nanoid";
import { Prompt, useHistory } from 'react-router-dom';
import validator from 'validator';
import { toast } from 'react-toastify';

const SignUp = () => {

    const dispatch = useDispatch()
    const history = useHistory()

    const [firstName, setFirstName] = useState("")
    const [lastName, setLastName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [confirmpassword, setConfirmPassword] = useState("")
    const [location, setLocation] = useState("")
    const [mobile, setMobile] = useState("")

    const [errorFields, setErrorFields] = useState({
        errFirstName: "",
        errLastName: "",
        errEmail: "",
        errLocation: "",
        errPassword: "",
        errCnfPassword: "",
        errMObile: "",
        errPasswordMatch: ""
    })

    const validate = () => {
        let errFirstName = ""
        let errLastName = ""
        let errEmail = ""
        let errLocation = ""
        let errPassword = ""
        let errCnfPassword = ""
        let errMObile = ""
        let errPasswordMatch = ""
        let mobilePattern = new RegExp(/^\d{10}$/)
        if (validator.isEmpty(firstName))
            errFirstName = "*First Name cannot be empty"
        if (validator.isEmpty(lastName))
            errLastName = "*Last Name cannot be empty"
        if (validator.isEmpty(location))
            errLocation = "*Location cannot be empty"
        if (validator.isEmpty(password))
            errPassword = "*Password cannot be empty"
        if (validator.isEmpty(confirmpassword))
            errCnfPassword = "*confirm password cannot be empty"
        if (validator.isEmpty(mobile))
            errMObile = "*Mobile number cannot be empty"
        else if (!mobilePattern.test(mobile))
            errMObile = "*Enter a valid mobile no"
        if (validator.isEmpty(email))
            errEmail = "*Email cannot be empty"
        else if (validator.isEmail(email))
            errEmail = "*Enter a vlid email"
        if (password !== confirmpassword)
            errPasswordMatch = "*Passwords do not Match"

        if (halfFilled() || !halfFilled()) {
            setErrorFields({
                errFirstName,
                errLastName,
                errEmail,
                errLocation,
                errPassword,
                errCnfPassword,
                errMObile,
                errPasswordMatch
            })
            return false
        }

        return true
    }
    //creating function to reset the form
    const resetForm = () => {
        setFirstName("")
        setLastName("")
        setEmail("")
        setMobile("")
        setPassword("")
        setConfirmPassword("")
        setLocation("")
    }
    const handleSubmit = (e) => {
        e.preventDefault()

        const isValid = validate()

        if (isValid) {
            return toast("Please fill all fields before submit", {
                type: "info"
            })
        }
        //creating user object
        const user = {
            id: nanoid(),
            firstName,
            lastName,
            email,
            password,
            location,
            mobile
        }
        //dispatch actionto add user
        dispatch(addUser(user))
        //resetting the form
        resetForm()
        //sending user to the home page
        history.push("/")
    }

    //checking if the form is half filled or not
    const halfFilled = () => {
        if (firstName || lastName || email || password || location || mobile) {
            return true
        } else
            return false
    }

    return (
        <Form className="w-50 mx-auto my-4" onSubmit={handleSubmit}>
            <Prompt
                when={halfFilled()}
                message={
                    (location) => `Are you sure you want to go to ${location.pathname}?`
                } />
            <Card>
                <CardHeader>SIGN UP</CardHeader>
                <CardBody>
                    <Row>
                        <FormGroup className="col-md-6">
                            <Label htmlFor="fname">First Name</Label>
                            <Input
                                type="text"
                                name="fname"
                                id="name"
                                value={firstName}
                                onChange={e => setFirstName(e.target.value)}
                                placeholder="Enter your First Name"
                                
                            />
                            {<span className="text-danger">{errorFields.errFirstName}</span>}
                        </FormGroup>
                        <FormGroup className="col-md-6">
                            <Label htmlFor="lname">Last Name</Label>
                            <Input
                                type="text"
                                name="lname"
                                id="lname"
                                value={lastName}
                                onChange={e => setLastName(e.target.value)}
                                placeholder="Enter your Last Name"
                                
                            />
                            {<span className="text-danger">{errorFields.errLastName}</span>}
                        </FormGroup>
                    </Row>
                    <Row>
                        <FormGroup className="col-md-6">
                            <Label htmlFor="email">Email</Label>
                            <Input
                                type="email"
                                name="email"
                                id="email"
                                value={email}
                                onChange={e => setEmail(e.target.value)}
                                placeholder="Enter your Email"
                                
                            />
                            {<span className="text-danger">{errorFields.errEmail}</span>}
                        </FormGroup>
                        <FormGroup className="col-md-6">
                            <Label htmlFor="mobile">Mobile No.</Label>
                            <Input
                                type="tel"
                                name="mobile"
                                id="mobile"
                                value={mobile}
                                onChange={e => setMobile(e.target.value)}
                                placeholder="Enter your Mobile no"
                                
                            />
                            {<span className="text-danger">{errorFields.errMObile}</span>}
                        </FormGroup>
                    </Row>
                    <Row>
                        <FormGroup className="col-md-6">
                            <Label htmlFor="password">Password</Label>
                            <Input
                                type="password"
                                name="password"
                                id="password"
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                placeholder="Enter your Password"
                                
                            />
                            {<span className="text-danger">{errorFields.errPassword}</span>}
                        </FormGroup>
                        <FormGroup className="col-md-6">
                            <Label htmlFor="cnfpassword">confirm Password</Label>
                            <Input
                                type="password"
                                name="cnfpassword"
                                id="cnfpassword"
                                value={confirmpassword}
                                onChange={e => setConfirmPassword(e.target.value)}
                                placeholder="confirm your Password"
                                
                            />
                            {<span className="text-danger">{errorFields.errCnfPassword}</span>}
                            {<span className="text-danger">{errorFields.errPasswordMatch}</span>}
                        </FormGroup>
                    </Row>

                    <FormGroup>
                        <Label htmlFor="location">Location</Label>
                        <Input type="select" value={location} onChange={e => setLocation(e.target.value)} name="location" id="location" placeholder="Enter your Location"  >
                            <option value="" disabled >Please select location</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Mumbai">Mumbai</option>
                            <option value="Hyderabad">Hyderabad</option>
                            <option value="Bangalore">Bangalore</option>
                            <option value="Noida">Noida</option>
                            <option value="Pune">Pune</option>
                            <option value="Chennai">Chennai</option>
                        </Input>
                        {<span className="text-danger">{errorFields.errLocation}</span>}
                    </FormGroup>
                </CardBody>
                <CardFooter>
                    <Button type="submit" color="primary">Sign Up</Button>
                    <Button type="button" onClick={resetForm} className="float-right" color="secondary">cancel</Button>
                </CardFooter>
            </Card>
        </Form>
    )
}

export default SignUp
