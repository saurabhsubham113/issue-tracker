export const ADD_ISSUE = "ADD_ISSUE"
export const VIEW_ISSUE = "VIEW_ISSUE"
export const VIEW_ONE_ISSUE = "VIEW_ONE_ISSUE"
export const UPDATE_ISSUE = "UPDATE_ISSUE"
export const DELETE_ISSUE = "DELETE_ISSUE"


export const ADD_USER = "ADD_USER"
export const GET_USER = "GET_USER"
export const LOG_OUT = "LOG_OUT"

